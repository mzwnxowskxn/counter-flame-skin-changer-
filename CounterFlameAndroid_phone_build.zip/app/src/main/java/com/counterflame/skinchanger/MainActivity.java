package com.counterflame.skinchanger;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(11,16,24);
    private final int PANEL = Color.rgb(18,27,41);
    private final int PANEL2 = Color.rgb(25,38,56);
    private final int ACCENT = Color.rgb(224,161,43);
    private final int WHITE = Color.rgb(237,242,247);
    private final int MUTED = Color.rgb(145,160,181);
    private final String[] weapons = {"AK-47", "M4A1", "AWP", "Нож", "Перчатки"};
    private final Map<String,String[]> catalog = new LinkedHashMap<>();
    private String currentWeapon = "AK-47";
    private String currentSkin = "Redline";
    private Uri importedImage = null;
    private ImageView preview;
    private TextView skinTitle, status;
    private LinearLayout skinList;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("skin_config", MODE_PRIVATE);
        catalog.put("AK-47", new String[]{"Redline","Neon Revolution","Slate","Импортированное изображение"});
        catalog.put("M4A1", new String[]{"Printstream","Decimator","Hyper Beast","Импортированное изображение"});
        catalog.put("AWP", new String[]{"Asiimov","Dragon Lore","Neo-Noir","Импортированное изображение"});
        catalog.put("Нож", new String[]{"Fade","Doppler","Crimson Web","Импортированное изображение"});
        catalog.put("Перчатки", new String[]{"Sport Gloves","Hand Wraps","Specialist Gloves","Импортированное изображение"});
        currentSkin = prefs.getString(currentWeapon, catalog.get(currentWeapon)[0]);
        buildUi();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = vertical();
        page.setPadding(dp(18), dp(18), dp(18), dp(24));
        page.setBackgroundColor(BG);
        scroll.addView(page);
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("CF", 27, ACCENT, true);
        header.addView(logo, lp(dp(48), dp(48)));
        LinearLayout brand = vertical();
        brand.addView(text("COUNTER FLAME", 18, WHITE, true));
        brand.addView(text("SKIN CHANGER  •  MOBILE", 10, MUTED, false));
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(header);
        status = text("●  ЛОКАЛЬНЫЕ НАСТРОЙКИ", 10, Color.rgb(76,175,131), true);
        LinearLayout.LayoutParams st = lp(-1,-2); st.topMargin=dp(12);
        page.addView(status, st);

        TextView heading = text("Настройка внешнего вида", 23, WHITE, true);
        LinearLayout.LayoutParams hp = lp(-1,-2); hp.topMargin=dp(25);
        page.addView(heading,hp);
        page.addView(text("Выбери категорию и сохрани любимый вариант.", 12, MUTED, false));

        page.addView(text("КАТЕГОРИИ", 11, MUTED, true), top(24));
        LinearLayout weaponRow = new LinearLayout(this);
        weaponRow.setOrientation(LinearLayout.HORIZONTAL);
        for (String w : weapons) {
            Button b = button(w, PANEL2, WHITE);
            b.setTextSize(11);
            b.setOnClickListener(v -> {
                currentWeapon = w;
                currentSkin = prefs.getString(w, catalog.get(w)[0]);
                refreshSkins();
            });
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(42), 1);
            bp.setMargins(dp(2),dp(3),dp(2),dp(3));
            weaponRow.addView(b,bp);
        }
        page.addView(weaponRow);

        page.addView(text("ДОСТУПНЫЕ СКИНЫ", 11, MUTED, true), top(22));
        skinList = vertical();
        skinList.setPadding(dp(10),dp(8),dp(10),dp(8));
        skinList.setBackground(shape(PANEL, dp(14)));
        page.addView(skinList, top(8));

        page.addView(text("ПРЕДПРОСМОТР", 11, MUTED, true), top(22));
        LinearLayout previewPanel = vertical();
        previewPanel.setPadding(dp(14),dp(14),dp(14),dp(14));
        previewPanel.setBackground(shape(PANEL,dp(14)));
        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(shape(PANEL2,dp(12)));
        preview.setAdjustViewBounds(true);
        preview.setMinimumHeight(dp(170));
        previewPanel.addView(preview,lp(-1,dp(190)));
        skinTitle = text(currentSkin,19,WHITE,true);
        previewPanel.addView(skinTitle,top(14));
        previewPanel.addView(text("Изображение можно добавить из галереи.",11,MUTED,false),top(4));
        Button importBtn = button("＋  Импортировать изображение", PANEL2, WHITE);
        importBtn.setOnClickListener(v -> pickImage());
        previewPanel.addView(importBtn,top(16));
        Button saveBtn = button("СОХРАНИТЬ ВЫБОР", ACCENT, Color.rgb(17,24,39));
        saveBtn.setOnClickListener(v -> {
            prefs.edit().putString(currentWeapon,currentSkin).apply();
            status.setText("●  ВЫБОР СОХРАНЁН");
            Toast.makeText(this,"Выбор сохранён на телефоне",Toast.LENGTH_SHORT).show();
        });
        previewPanel.addView(saveBtn,top(9));
        page.addView(previewPanel,top(8));

        TextView note = text("Самостоятельный каталог. Не изменяет файлы Counter Flame и не применяет скины внутри игры.",10,MUTED,false);
        page.addView(note,top(18));
        refreshSkins();
    }

    private LinearLayout.LayoutParams top(int margin) {
        LinearLayout.LayoutParams p = lp(-1,-2); p.topMargin=dp(margin); return p;
    }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    private Button button(String label, int color, int textColor) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(textColor); b.setAllCaps(false);
        b.setTextSize(13); b.setBackground(shape(color,dp(10)));
        return b;
    }

    private void refreshSkins() {
        if (skinList == null) return;
        skinList.removeAllViews();
        for (String skin : catalog.get(currentWeapon)) {
            Button b = button((skin.equals(currentSkin) ? "✓  " : "   ") + skin,
                    skin.equals(currentSkin) ? Color.rgb(38,61,56) : PANEL2, WHITE);
            b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
            b.setOnClickListener(v -> {
                currentSkin=skin; skinTitle.setText(skin); refreshSkins();
                if (importedImage != null) preview.setImageURI(importedImage);
                else preview.setImageDrawable(null);
            });
            skinList.addView(b,top(5));
        }
        skinTitle.setText(currentSkin);
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 42);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == 42 && resultCode == RESULT_OK && data != null) {
            importedImage = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(importedImage,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            preview.setImageURI(importedImage);
            status.setText("●  ИЗОБРАЖЕНИЕ ЗАГРУЖЕНО");
        }
    }
}
